package com.mitocode.model;

public class Celda {

	private int idFila;
	private int idColumna;
	private String valor;

	public int getIdFila() {
		return idFila;
	}

	public void setIdFila(int idFila) {
		this.idFila = idFila;
	}

	public int getIdColumna() {
		return idColumna;
	}

	public void setIdColumna(int idColumna) {
		this.idColumna = idColumna;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

}
